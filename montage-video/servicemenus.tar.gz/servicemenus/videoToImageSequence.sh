#!/bin/bash

for name in "$@"
do
    kdialog --passivepopup "Creating image sequence for $name" 5
    ffmpeg -i $name -qscale:v 2 -vsync 0 ${name%.*}-%06d.jpg
done
kdialog --passivepopup "Images have been generated successfully" 10
